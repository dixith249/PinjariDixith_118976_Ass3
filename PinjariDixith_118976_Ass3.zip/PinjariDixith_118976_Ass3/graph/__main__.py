
#Importing graph, node and algorithm
from graph import *
#Creating graph
myGraph=Graph()

#List of cities
cityList=['Berlin','Braunschweig','Hannover','Bremen','Leipzig','Jena','Weimar',
        'Erfurt','Dortmund','Essen','Dusseldorf','Leverkusen','Krefeld','Frankfurt',
        'Mainz','Nuremberg','Mannheim','Munich','Augsburg','Stuttgart','Freiburg']

#Dictionary to store nodes
c={}
#Create nodes with corresponding labels
# and add them to myGraph
for city in cityList:
    c[city]=Node(city)
    myGraph.addNode(c[city])

#Dictionary of dictionaries, containing connections and their distances
#{ 'CITY' : { 'DESTINATION' : DISTANCE } }
connections={
        'Berlin':{'Hannover':300,'Leipzig':190,'Braunschweig':227},
        'Braunschweig':{},
        'Hannover':{'Braunschweig':88,'Dortmund':211},
        'Bremen':{'Hannover':127},
        'Leipzig':{'Jena':105},
        'Jena':{'Nuremberg':226},
        'Weimar':{'Jena':23,'Leipzig':130},
        'Erfurt':{'Berlin':237,'Frankfurt':262,'Weimar':23},
        'Dortmund':{'Bremen':234,'Dusseldorf':70},
        'Essen':{'Dortmund':35},
        'Dusseldorf':{'Essen':48,'Leverkusen':53},
        'Leverkusen':{'Krefeld':85,'Mainz':185},
        'Krefeld':{'Dusseldorf':33},
        'Frankfurt':{'Hannover':573,'Mainz':43,'Nuremberg':224,'Leverkusen':196},
        'Mainz':{'Mannheim':124},
        'Nuremberg':{'Stuttgart':210,'Augsburg':148},
        'Mannheim':{'Frankfurt':124},
        'Munich':{'Freiburg':351,'Nuremberg':169,'Berlin':840},
        'Augsburg':{'Stuttgart':164,'Munich':79},
        'Stuttgart':{'Freiburg':206,'Mannheim':90},
        'Freiburg':{'Bremen':1250,'Mannheim':194}
        }

#Creating connections
for city in cityList:
    for destination,distance in connections[city].items():
        c[city].connect(c[destination],distance)


#Testing quickSearch function
print('quickSearch tests: ')
#List of lists for testing
lists=[
	[6,78,1,5,7,98,2,5,4],
	[0,9,4,-23,4,6,7,2,10],
	[-5.5,23,9.9,10,12.5,222.3],
	[0.0,0,0.0,2,1,-2,-0.4,0.8]
	]

for li in lists:
	print('Before sort:')
	print(li)
	print('After sort:')
	print(quickSort(li))
	print()

#Testing Djikstra
print('Djikstra tests:')

#Creating algorithm object
alg=Djikstra(myGraph)

#Making a function that will print path and distance properly
def printPath(source,target):
	#You can get shortest distance between any 2 cities
	# cities can be written both like 'CITY' and c['CITY']
	
	#Algorithm
	path,distance=alg.searchPath(source,target)
	
	#In case source or target are nodes ( given as c['CITY'] ), we get their labels for proper printing
	if type(source)!=str:
		source=source.label
	if type(target)!=str:
		target=target.label
	
	print('Path from '+source+' to '+target)
	
	#If path is None then there's no way from source to target
	if path==None:
		print('Impossible destination')
	else:
		#Printing path from source to target
		for i in path:
			print(i.label)
		#Printing total shortest path length
		print('Total distance: '+str(distance))
		print()


#Creating a dictionary { source : target } for testing
travels={
		c['Freiburg']:c['Bremen'],
		'Braunschweig':'Dortmund',
		'Berlin':c['Freiburg'],
		c['Erfurt']:'Nuremberg'
		}

for source,target in travels.items():
	printPath(source,target)

print('You can sort any list of numbers using function quickSort(list)')
print('You can get path from one city to another using function printPath(city1,city2)')
print('List of cities:')
print(cityList)