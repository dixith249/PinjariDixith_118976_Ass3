import math

#Recursive quicksort algorithm to sort min-priority queue
def quickSort(array):
	#If array has 1 or 0 elements, then we don't need sorting 
	if len(array)<=1:
		return array
	#Arrays for values greater, equal and less than pivot
	more = []
	equal = []
	less = []
	#Taking first value as a pivot
	pivot = array[0]
	#Adding values to arrays
	for value in array:
		if value>pivot:
			more.append(value)
		elif value==pivot:
			equal.append(value)
		else:
			less.append(value)
	#Sorting arrays more and less
	more = quickSort(more)
	less = quickSort(less)
	#Returning sorted array
	return less + equal + more

class Graph(object):
	
    # TODO: implement additional constructors
	#A constructor for the class which can take a list of nodes
	def __init__(self,nodes=[]):
        #Copying into a new list
		self._nodes = list(nodes)
		#queue is used in search algorithm
		self._minPriorityQueue=[]
	
	#Method that allows us to iterate over all nodes in graph like this:
	# for node in graph
	def __iter__(self):
		return iter(self._nodes)
	
	# TODO: implement method for adding a node
	#This function can accept a node or label as first argument, and also other parameters or node
	def addNode(self,node_or_label,adjacentNodes = {},parent = None,distance = math.inf):
		node = node_or_label
		#if it is string, then create node with this label
		if type(node)==str:
			node = Node(node,adjacentNodes,parent,distance)
		else:
			#If it is a node, then just add new connections if needed
			for key,value in adjacentNodes.items():
				node.connect(key,value)
		#Adding node to list
		self._nodes.append(node)
		
	# TODO: implement method for removing a node
	#Takes a node, a label or index in _nodes and deletes the node
	def removeNode(self,node_or_label_or_index):
		#If it's a string, then it's a label
		if type(node_or_label_or_index)==str:
			#Search node with this label and delete it
			for i in range(self._nodes):
				if self._nodes[i].label==node_or_label_or_index:
					del self._nodes[i]
					break
		#if it's int, then it's index
		elif type(node_or_label_or_index)==int:
			#Just delete this index
			del self._nodes[node_or_label_or_index]
		#Else it's a node
		else:
			#Search this node and delete it
			for i in range(self._nodes):
				if self._nodes[i]==node_or_label_or_index:
					del self._nodes[i]
					break
	
	#Function for adding to queue
	def addQueue(self,node):
		self._minPriorityQueue.append(node)
	
	# TODO: implement method for sorting the min-priority Queue
	def sortQueue(self):
		#Extracting values of nodes into an array
		values = [i.distance for i in self._minPriorityQueue]
		#Sorting values using quicksort
		values = quickSort(values)
		#Empty array
		sortedQueue = []
		#Adding nodes to new queue one by one
		for val in values:
			#Searching a node with this distance
			for node in self._minPriorityQueue:
				#Also checking if this node wasn't added already
				# in case of nodes with same distance
				if node.distance==val and not(node in sortedQueue):
					#Appending the node
					sortedQueue.append(node)
					#Breaking for loop because we want only one node per value
					break
		#Using sorted queue as main queue
		self._minPriorityQueue=sortedQueue
	
	# TODO: implement method for extracting 0-element from the min-priority Queue
	def popQueue(self):
		#Checking if the queue is empty
		if len(self._minPriorityQueue)>0:
			#Saving the node to variable
			node=self._minPriorityQueue[0]
			#Deleting node from array
			del self._minPriorityQueue[0]
			#Returning
			return node
		else:
			#If queue is empty, return None
			return None
	
	# TODO: implement Djikstra (in another class)

class Node(object):
	
	# TODO: implement additional constructors
	#A constructor for the class which needs a label, and can accept adjacent nodes if needed
	def __init__(self,lab, adjNodes = {}):
		self.label = lab
        #Copying into a new dictionary
		self.adjacentNodes = dict(adjNodes)
		#Parent and distance are used in search algorithm
		self.parent = None
		self.distance = math.inf
	
	#Method that allows us to iterate over all adjacent nodes of this node like this:
	# for adjacent,distance in node
	def __iter__(self):
		return iter(self.adjacentNodes.items())
	
	# TODO: implement method for adding a connection
	def connect(self,node,distance):
		self.adjacentNodes[node] = distance
	
	# TODO: implement method for removing a connection
	def disconnect(self,node):
		#Checking if node is connected
		if self.adjacentNodes.get(node)!=None:
			del self.adjacentNodes[node]
	
	# TODO: implement methods for manipulating the parent and distance
	def setParent(self,node):
		self.parent = node
	
	def getParent(self):
		return self.parent
	
	def setDistance(self,distance):
		self.distance = distance
	
	def getDistance(self):
		return self.distance

# TODO: implement Djikstra (in another class)
#Class that has method for finding shortest path
class Djikstra(object):
	graph = None # Graph on which algorithm will search path
	
	#Constructor that takes a graph
	def __init__(self,graph = None):
		self.graph = graph
	
	#Function for setting a different graph
	def setGraph(self, graph = None):
		self.graph = graph
	
	#Function for getting graph
	def getGraph(self):
		return self.graph
	
	#Function for searching shortest path from source to target
	def searchPath(self,source,target):
		#We can iterate over all nodes in graph, thanks to __iter__ method
		
		#In case that source or target are given as labels:
		if type(source)==str:
			#Search for node with this label
			for i in self.graph:
				if i.label==source:
					source = i
					#Break after we find this node
					break
		#Same for target
		if type(target)==str:
			#Search for node with this label
			for i in self.graph:
				if i.label==target:
					target = i
					#Break after we find this node
					break
		
		#Setting parents and distances to starting values for all nodes
		for node in self.graph:
			#None and math.inf means that we did not find path here yet
			node.setParent(None)
			#Distance here stands for shortest path found from source to this node
			node.setDistance(math.inf)
		#Clearing queue of graph just in case it is not empty
		pop = self.graph.popQueue()
		while pop!=None:
			pop = self.graph.popQueue()
		#Distance to source is 0
		source.setDistance(0)
		#Start search with source
		self.graph.addQueue(source)
		#Starting while loop that will end when queue of graph is empty
		pop = self.graph.popQueue()
		while pop!=None:
			#Iterating over all adjacent nodes of source node thanks to __iter__ method
			#Setting parent and distance for all adjacent nodes of current pop
			for node,distance in pop:
				#This is total distance from source to this node using path through pop
				distance = distance + pop.getDistance()
				#Checking if distance throught pop is better than previous path to this node
				#If it is math.inf, than there was no path here before and we set it anyway
				if distance<node.getDistance():
					#We found a better path, so we save it
					node.setDistance(distance)
					#We also save parent so we know which path it is
					node.setParent(pop)
					#Now we add this node to queue, so further path through it can be searched
					self.graph.addQueue(node)
			pop = self.graph.popQueue()
		#When loop is completed, that means we have shortest distance from source to all nodes,
		# distance is saved in every node
		#If parent of target is still None, then there's no way from source to target
		if target.getParent()==None:
			#Returning None instead of path, and math.inf istead of distance
			return None,math.inf
		#We can track path from source to distance if we go from target to source like this:
		#Destination is end-point in our path
		path=[target]
		#Loop continues until source is the starting point in our path
		while path[0]!=source:
			node=path[0]
			#We started from end, so we add points to the beginning
			path.insert(0,node.getParent())
		#Total distance from source to target
		totalDistance=target.getDistance()
		#Now we return list of points, which is our path, as well as distance
		return path,totalDistance
		
	
